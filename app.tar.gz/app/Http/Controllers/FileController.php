<?php

namespace App\Http\Controllers;

use App\Http\Requests\FileRequest;
use App\Models\File;
use \Illuminate\Http\Request;

class FileController extends Controller
{
    public function addFile(Request $request): array{

        if($request->hasFile('file')){
            $files = $request->file('file');
            foreach ($files as $file) {
                $file->store('files');
                File::create(['file_uniq'=>$file->hashName(),'path' => 'files/' . $file->hashName(), 'name' => $file->getClientOriginalName()]);
            }
            return [
                'success' => true,
                'message' => 'File successfully uploaded'
            ];
        } else {
            return ['success' => false,
                'message' => 'File not uploaded'];
        }
    }
}
